package com.hactiv8.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView scoreTv;
    Button buttonCount;
    EditText nameEt;
    int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scoreTv = findViewById(R.id.score);
        buttonCount = findViewById(R.id.button_count);
        nameEt = findViewById(R.id.nameEt);

        buttonCount.setOnClickListener(this);

        if (savedInstanceState != null){
            String count = savedInstanceState.getString("count");
            if(scoreTv != null)
                scoreTv.setText(count);
        }
    }

    @Override
    public void onClick(View view) {
        String currentScore = scoreTv.getText().toString();
        int currentScoreInt = Integer.valueOf(currentScore);
        score=currentScoreInt+1;
        scoreTv.setText(String.valueOf(score));
    }

    public  void onSaveInstanceState (Bundle outState) {

        super.onSaveInstanceState(outState);
        outState.putString("count", String.valueOf(scoreTv.getText()));
    }

//    public void onRestoreInstanceStats (Bundle mySavedState){
//        super.onRestoreInstanceState(mySavedState);
//        if (mySavedState != null){
//            String count = mySavedState.getString("count");
//            if (count != null) scoreTv.setText(count);
//        }
//    }
}